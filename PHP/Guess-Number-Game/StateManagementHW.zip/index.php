<?php
include_once 'templates/header.html';
include_once 'templates/start-form.html';
include_once 'templates/footer.html';