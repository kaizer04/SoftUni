﻿namespace StudentSystem.Model
{
    public enum ContentType
    {
        ApplicationPdf, 
        ApplicationZip
    }
}
