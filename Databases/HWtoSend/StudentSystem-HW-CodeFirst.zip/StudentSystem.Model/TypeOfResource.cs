﻿namespace StudentSystem.Model
{
    public enum TypeOfResource
    {
        Video, 
        Presentation,
        Document,
        Other
    }
}
