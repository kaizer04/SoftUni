﻿namespace News.Model
{
    public class News
    {
        public int Id { get; set; }

        public string Content { get; set; }
    }
}
