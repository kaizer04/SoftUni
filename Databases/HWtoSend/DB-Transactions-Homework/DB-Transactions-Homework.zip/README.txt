Please, config conectionstrings

copy->paste to App.Config




FOR ATMPROJECT:

<connectionStrings>
    <add name="ATMEntities" connectionString="metadata=res://*/ATMDbContext.csdl|res://*/ATMDbContext.ssdl|res://*/ATMDbContext.msl;provider=System.Data.SqlClient;provider connection string=&quot;data source=.;initial catalog=ATM;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework&quot;" providerName="System.Data.EntityClient" />
  </connectionStrings>