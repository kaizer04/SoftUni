﻿'use strict'

var app = angular.module('bindImage', []);
