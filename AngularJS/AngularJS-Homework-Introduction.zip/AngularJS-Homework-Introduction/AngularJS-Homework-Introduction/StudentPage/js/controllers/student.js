﻿'use strict';

app.controller('Student', function ($scope) {
    $scope.name = "Pesho";
    $scope.photo = "http://www.nakov.com/wp-content/uploads/2014/05/SoftUni-Logo.png";
    $scope.grade = 5;
    $scope.school = "High School of Mathematics";
    $scope.teacher = "Gichka Pesheva";
});