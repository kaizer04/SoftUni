﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportSystem.Common
{
    public class GlobalConstants
    {
        public const int HomePageNumberOfMatches = 3;

        public const int DefaultStartPage = 1;
        public const int DefaultPageSize = 6;
    }
}
