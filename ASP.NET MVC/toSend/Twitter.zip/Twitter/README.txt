added Models project
added Web project
copy driven development for ApplicationUser to Models.User
instal Identity EntityFramework for Models