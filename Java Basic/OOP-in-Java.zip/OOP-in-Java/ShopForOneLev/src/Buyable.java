
public interface Buyable {
	double getPrice();
}
