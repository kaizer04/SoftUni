public enum AgeRestriction {
	None,
	Teenager,
	Adult
}
