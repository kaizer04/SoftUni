package shapes;

public interface AreaMeasurable {
	double getArea();
}
