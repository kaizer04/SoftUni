package shapes;

public interface PerimeterMeasurable {
	double getPerimeter();
}
