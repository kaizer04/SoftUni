package shapes;

public abstract class Shape {
	protected double[] vertexCoordinates;
}
