package shapes;

public interface VolumeMeasurable {
	double getVolume();
}
