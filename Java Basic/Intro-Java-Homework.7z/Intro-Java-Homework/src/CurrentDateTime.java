
import java.util.Date;

public class CurrentDateTime {

	public static void main(String[] args) {
		Date dateTime = new Date();
		System.out.println(dateTime);

	}

}
