import java.util.Scanner;

public class RectangleArea {
	public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double a = in.nextDouble();
        double b = in.nextDouble();
       
        double rectangleArea = a*b;
       
        System.out.println(rectangleArea);
       
	}
}
