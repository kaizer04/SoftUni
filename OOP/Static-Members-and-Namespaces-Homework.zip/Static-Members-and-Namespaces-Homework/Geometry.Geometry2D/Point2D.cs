﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


// I feel stupid to add all empty classes :)
namespace Geometry.Geometry2D
{
    class Point2D
    {
    }
}
