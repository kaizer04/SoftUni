﻿namespace _02.Bank
{
    public interface IMoneyDrawable
    {
        void DrawMoney(decimal ammount, decimal periodInMonth);
    }
}
