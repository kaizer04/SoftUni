﻿namespace _02.Bank
{
    public class Company : Customer
    {
        public Company(string name) 
            : base(name)
        {

        }
    }
}
