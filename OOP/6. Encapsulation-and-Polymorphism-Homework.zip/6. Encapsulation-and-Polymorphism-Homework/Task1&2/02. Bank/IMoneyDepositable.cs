﻿namespace _02.Bank
{
    public interface IMoneyDepositable
    {
        void DepositMoney(decimal ammount, decimal periodInMonth);
    }
}
