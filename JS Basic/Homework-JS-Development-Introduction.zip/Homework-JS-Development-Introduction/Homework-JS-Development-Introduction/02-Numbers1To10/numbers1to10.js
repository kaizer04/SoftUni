﻿window.onload = function () {
    var numberTo = 10;
    for (var i = 1; i <= numberTo; i += 1) {
        console.log(i);
    }
}();

//If tou do not have node, you can start numbers1to10.html 