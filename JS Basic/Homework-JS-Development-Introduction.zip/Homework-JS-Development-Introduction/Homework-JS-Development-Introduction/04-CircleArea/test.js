﻿var div = document.createElement('DIV');
