﻿window.onload = function () {
    var town = 'Sofia';
    alert(town);
}();